# Mostrar los múltiplos de 8 hasta el valor de 500
# Debe aparecer en pantalla 8 - 16 - 24, etc.
num=8
while num<=500:
    print(num,"-", end="")
    num=num+8
