# Realizar un programa que imprima 25 términos de la serie
# 11 - 22 - 33 - 44, etc. (No se ingresan valores por teclado)
num=11
for x in range (25):
    print (num)
    num=num+11
